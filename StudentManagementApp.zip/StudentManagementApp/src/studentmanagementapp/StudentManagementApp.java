/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package studentmanagementapp;


import java.util.ArrayList; 

import java.util.List; 

import java.util.Scanner; 

 

public class StudentManagementApp { 

    static List<Student> students = new ArrayList<>(); 

 

    public static void main(String[] args) { 

        Scanner scanner = new Scanner(System.in); 

        while (true) { 

            displayMenu(); 

            String choice = scanner.nextLine(); 

            switch (choice) { 

                case "1": 

                    addStudent(scanner); 

                    break; 

                case "2": 

                    searchStudent(scanner); 

                    break; 

                case "3": 

                    deleteStudent(scanner); 

                    break; 

                case "4": 

                    printStudentReport(); 

                    break; 

                case "5": 

                    System.out.println("Exiting application."); 

                    return; 

                default: 

                    System.out.println("Invalid option. Please try again."); 

            } 

        } 

    } 

 

    private static void displayMenu() { 

        System.out.println("STUDENT MANAGEMENT APPLICATION"); 

        System.out.println("*******************************"); 

        System.out.println("Enter (1) to add a new student."); 

        System.out.println("Enter (2) to search for a student."); 

        System.out.println("Enter (3) to delete a student."); 

        System.out.println("Enter (4) to print student report."); 

        System.out.println("Enter (5) to exit application."); 

        System.out.print("Please select an option: "); 

    } 

 

    static void addStudent(Scanner scanner) { 

        System.out.println("CAPTURE A NEW STUDENT"); 

        System.out.print("Enter the student id: "); 

        String id = scanner.nextLine(); 

        System.out.print("Enter the student name: "); 

        String name = scanner.nextLine(); 

 

        int age; 

        while (true) { 

            System.out.print("Enter the student age: "); 

            try { 

                age = Integer.parseInt(scanner.nextLine()); 

                if (age < 16) { 

                    System.out.println("You have entered an incorrect student age!!!"); 

                    continue; 

                } 

                break; 

            } catch (NumberFormatException e) { 

                System.out.println("You have entered an incorrect student age!!!"); 

            } 

        } 

 

        System.out.print("Enter the student email: "); 

        String email = scanner.nextLine(); 

        System.out.print("Enter the student course: "); 

        String course = scanner.nextLine(); 

 

        Student student = new Student(id, name, age, email, course); 

        students.add(student); 

        System.out.println("Student details have been successfully saved!"); 

    } 

 

    static void searchStudent(Scanner scanner) { 

        System.out.print("Enter the student ID to search: "); 

        String id = scanner.nextLine(); 

        Student student = findStudentById(id); 

 

        if (student != null) { 

            System.out.println("Student found:"); 

            printStudentDetails(student); 

        } else { 

            System.out.println("Student with ID: " + id + " cannot be found."); 

        } 

    } 

 

    static void deleteStudent(Scanner scanner) { 

        System.out.print("Enter the student ID to delete: "); 

        String id = scanner.nextLine(); 

        Student student = findStudentById(id); 

 

        if (student != null) { 

            System.out.print("Are you sure you want to delete student with ID: " + id + "? Yes (y) to delete: "); 

            String confirmation = scanner.nextLine(); 

            if (confirmation.equalsIgnoreCase("y")) { 

                students.remove(student); 

                System.out.println("Student with ID: " + id + " has been deleted!"); 

            } 

        } else { 

            System.out.println("Student with ID: " + id + " cannot be found."); 

        } 

    } 

 

    static void printStudentReport() { 

        if (students.isEmpty()) { 

            System.out.println("No students to display."); 

        } else { 

            System.out.println("STUDENT REPORT:"); 

            for (Student student : students) { 

                printStudentDetails(student); 

                System.out.println("*******************************"); 

            } 

        } 

    } 

 

    static Student findStudentById(String id) { 

        for (Student student : students) { 

            if (student.getId().equals(id)) { 

                return student; 

            } 

        } 

        return null; 

    } 

 

    static void printStudentDetails(Student student) { 

        System.out.println("STUDENT ID: " + student.getId()); 

        System.out.println("STUDENT NAME: " + student.getName()); 

        System.out.println("STUDENT AGE: " + student.getAge()); 

        System.out.println("STUDENT EMAIL: " + student.getEmail()); 

        System.out.println("STUDENT COURSE: " + student.getCourse()); 

    } 

 

    static class Student { 

        private String id; 

        private String name; 

        private int age; 

        private String email; 

        private String course; 

 

        public Student(String id, String name, int age, String email, String course) { 

            this.id = id; 

            this.name = name; 

            this.age = age; 

            this.email = email; 

            this.course = course; 

        } 

 

        // Getters and setters 

        public String getId() { return id; } 

        public void setId(String id) { this.id = id; } 

 

        public String getName() { return name; } 

        public void setName(String name) { this.name = name; } 

 

        public int getAge() { return age; } 

        public void setAge(int age) { this.age = age; } 

 

        public String getEmail() { return email; } 

        public void setEmail(String email) { this.email = email; } 

 

        public String getCourse() { return course; } 

        public void setCourse(String course) { this.course = course; } 

 

        public boolean isValidAge() { 

            return this.age >= 16; 

        } 

    } 

} 
