/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package weddingarranger;

/**
 *
 * @author RC_ST10461720 Palesa M
 */
import java.util.ArrayList; 
import java.util.Scanner; 
import java.util.Date; 
import java.text.ParseException; 
import java.text.SimpleDateFormat; 
 
public class WeddingArranger { 
 
    // Define the Venue superclass 
    static class Venue { 
        protected String name; 
        protected int capacity; 
 
        public Venue(String name, int capacity) { 
            this.name = name; 
            this.capacity = capacity; 
        } 
 
        public String getName() { 
            return name; 
        } 
 
        public int getCapacity() { 
            return capacity; 
        } 
 
        @Override 
        public String toString() { 
            return name + " (Capacity: " + capacity + ")"; 
        } 
    } 
 
    // Define the ReceptionVenue subclass 
    static class ReceptionVenue extends Venue { 
        private boolean hasCatering; 
 
        public ReceptionVenue(String name, int capacity, boolean hasCatering) { 
            super(name, capacity); 
            this.hasCatering = hasCatering; 
        } 
 
        public boolean hasCatering() { 
            return hasCatering; 
        } 
 
        @Override 
        public String toString() { 
            return super.toString() + ", Catering: " + (hasCatering ? "Yes" : "No"); 
        } 
    } 
 
    // Define the CeremonyVenue subclass 
    static class CeremonyVenue extends Venue { 
        private boolean hasOutdoorSpace; 
 
        public CeremonyVenue(String name, int capacity, boolean hasOutdoorSpace) { 
            super(name, capacity); 
            this.hasOutdoorSpace = hasOutdoorSpace; 
        } 
 
        public boolean hasOutdoorSpace() { 
            return hasOutdoorSpace; 
        } 
 
        @Override 
        public String toString() { 
            return super.toString() + ", Outdoor Space: " + (hasOutdoorSpace ? "Yes" : "No"); 
        } 
    } 
 
    // Define the Wedding class 
    static class Wedding { 
        private Venue venue; 
        private Date date; 
 
        public Wedding(Venue venue, Date date) { 
            this.venue = venue; 
            this.date = date; 
        } 
 
        public Venue getVenue() { 
            return venue; 
        } 
 
        public Date getDate() { 
            return date; 
        } 
 
        @Override 
        public String toString() { 
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy"); 
            return "Venue: " + venue + ", Date: " + sdf.format(date); 
        } 
    } 
 
    private ArrayList<Venue> venues = new ArrayList<>(); 
    private ArrayList<Wedding> weddings = new ArrayList<>(); 
    private Scanner scanner = new Scanner(System.in); 
    private SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy"); 
 
    public static void main(String[] args) { 
        WeddingArranger app = new WeddingArranger(); 
        app.run(); 
    } 
 
    public void run() { 
        while (true) { 
            System.out.println("1. Add Venue"); 
            System.out.println("2. List Venues"); 
            System.out.println("3. Arrange Wedding"); 
            System.out.println("4. List Weddings"); 
            System.out.println("5. Search Weddings by Date"); 
            System.out.println("6. Delete a Wedding"); 
            System.out.println("7. Update Venue Details"); 
            System.out.println("8. Filter Venues by Type"); 
            System.out.println("9. Count Weddings per Venue"); 
            System.out.println("10. Exit"); 
            System.out.print("Choose an option: "); 
            int choice = scanner.nextInt(); 
            scanner.nextLine(); // Consume newline 
 
            switch (choice) { 
                case 1: 
                    addVenue(); 
                    break; 
                case 2: 
                    listVenues(); 
                    break; 
                case 3: 
                    arrangeWedding(); 
                    break; 
                case 4: 
                    listWeddings(); 
                    break; 
                case 5: 
                    searchWeddingsByDate(); 
                    break; 
                case 6: 
                    deleteWedding(); 
                    break; 
                case 7: 
                    updateVenueDetails(); 
                    break; 
                case 8: 
                    filterVenuesByType(); 
                    break; 
                case 9: 
                    countWeddingsPerVenue(); 
                    break; 
                case 10: 
                    System.out.println("Exiting..."); 
                    return; 
                default: 
                    System.out.println("Invalid choice. Try again."); 
            } 
        } 
    } 
 
    private void addVenue() { 
        System.out.print("Enter venue type (Reception/Ceremony): "); 
        String type = scanner.nextLine(); 
        System.out.print("Enter venue name: "); 
        String name = scanner.nextLine(); 
        System.out.print("Enter venue capacity: "); 
        int capacity = scanner.nextInt(); 
        scanner.nextLine(); // Consume newline 
 
        if (type.equalsIgnoreCase("Reception")) { 
            System.out.print("Has catering (yes/no): "); 
            boolean hasCatering = scanner.nextLine().equalsIgnoreCase("yes"); 
            venues.add(new ReceptionVenue(name, capacity, hasCatering)); 
        } else if (type.equalsIgnoreCase("Ceremony")) { 
            System.out.print("Has outdoor space (yes/no): "); 
            boolean hasOutdoorSpace = scanner.nextLine().equalsIgnoreCase("yes"); 
            venues.add(new CeremonyVenue(name, capacity, hasOutdoorSpace)); 
        } else { 
            System.out.println("Invalid venue type."); 
        } 
    } 
 
    private void listVenues() { 
        if (venues.isEmpty()) { 
            System.out.println("No venues available."); 
            return; 
        } 
 
        System.out.println("List of Venues:"); 
        for (Venue venue : venues) { 
            System.out.println(venue); 
        } 
    } 
 
    private void arrangeWedding() { 
        if (venues.isEmpty()) { 
            System.out.println("No venues available. Add a venue first."); 
            return; 
        } 
 
        System.out.println("Select a venue:"); 
        for (int i = 0; i < venues.size(); i++) { 
            System.out.println((i + 1) + ". " + venues.get(i)); 
        } 
        System.out.print("Enter the number of the venue: "); 
        int venueIndex = scanner.nextInt() - 1; 
        scanner.nextLine(); // Consume newline 
 
        if (venueIndex < 0 || venueIndex >= venues.size()) { 
            System.out.println("Invalid venue number."); 
            return; 
        } 
 
        Venue selectedVenue = venues.get(venueIndex); 
 
        System.out.print("Enter the wedding date (dd/MM/yyyy): "); 
        String dateStr = scanner.nextLine(); 
        Date date; 
        try { 
            date = sdf.parse(dateStr); 
        } catch (ParseException e) { 
            System.out.println("Invalid date format."); 
            return; 
        } 
 
        weddings.add(new Wedding(selectedVenue, date)); 
        System.out.println("Wedding arranged successfully."); 
    } 
 
    private void listWeddings() { 
        if (weddings.isEmpty()) { 
            System.out.println("No weddings arranged."); 
            return; 
        } 
 
        System.out.println("List of Weddings:"); 
        for (Wedding wedding : weddings) { 
            System.out.println(wedding); 
        } 
    } 
 
    private void searchWeddingsByDate() { 
        System.out.print("Enter the date to search (dd/MM/yyyy): "); 
        String dateStr = scanner.nextLine(); 
        Date searchDate; 
        try { 
            searchDate = sdf.parse(dateStr); 
        } catch (ParseException e) { 
            System.out.println("Invalid date format."); 
            return; 
        } 
 
        boolean found = false; 
        for (Wedding wedding : weddings) { 
            if (wedding.getDate().equals(searchDate)) { 
                System.out.println(wedding); 
                found = true; 
            } 
        } 
 
        if (!found) { 
            System.out.println("No weddings found on this date."); 
        } 
    } 
 
    private void deleteWedding() { 
        if (weddings.isEmpty()) { 
            System.out.println("No weddings to delete."); 
            return; 
        } 
 
        System.out.println("Select a wedding to delete:"); 
        for (int i = 0; i < weddings.size(); i++) { 
            System.out.println((i + 1) + ". " + weddings.get(i)); 
        } 
        System.out.print("Enter the number of the wedding: "); 
        int weddingIndex = scanner.nextInt() - 1; 
        scanner.nextLine(); // Consume newline 
 
        if (weddingIndex < 0 || weddingIndex >= weddings.size()) { 
            System.out.println("Invalid wedding number."); 
            return; 
        } 
 
        weddings.remove(weddingIndex); 
        System.out.println("Wedding deleted successfully."); 
    } 
 
    private void updateVenueDetails() { 
        if (venues.isEmpty()) { 
            System.out.println("No venues to update."); 
            return; 
        } 
 
        System.out.println("Select a venue to update:"); 
        for (int i = 0; i < venues.size(); i++) { 
            System.out.println((i + 1) + ". " + venues.get(i)); 
        } 
        System.out.print("Enter the number of the venue: "); 
        int venueIndex = scanner.nextInt() - 1; 
        scanner.nextLine(); // Consume newline 
 
        if (venueIndex < 0 || venueIndex >= venues.size()) { 
            System.out.println("Invalid venue number."); 
            return; 
        } 
 
        Venue selectedVenue = venues.get(venueIndex); 
        System.out.print("Enter new name for the venue: "); 
        String newName = scanner.nextLine(); 
        System.out.print("Enter new capacity: "); 
        int newCapacity = scanner.nextInt(); 
        scanner.nextLine(); // Consume newline 
 
        if (selectedVenue instanceof ReceptionVenue) { 
            System.out.print("Has catering (yes/no): "); 
            boolean newCatering = scanner.nextLine().equalsIgnoreCase("yes"); 
            venues.set(venueIndex, new ReceptionVenue(newName, newCapacity, 
newCatering)); 
        } else if (selectedVenue instanceof CeremonyVenue) { 
            System.out.print("Has outdoor space (yes/no): "); 
            boolean newOutdoorSpace = scanner.nextLine().equalsIgnoreCase("yes"); 
            venues.set(venueIndex, new CeremonyVenue(newName, newCapacity, 
newOutdoorSpace)); 
        } 
 
        System.out.println("Venue details updated successfully."); 
    } 
 
    private void filterVenuesByType() { 
        System.out.print("Enter venue type to filter (Reception/Ceremony): "); 
        String type = scanner.nextLine(); 
 
        boolean found = false; 
        for (Venue venue : venues) { 
            if (type.equalsIgnoreCase("Reception") && venue instanceof ReceptionVenue) { 
                System.out.println(venue); 
                found = true; 
            } else if (type.equalsIgnoreCase("Ceremony") && venue instanceof CeremonyVenue) { 
                System.out.println(venue); 
                found = true; 
            } 
        } 
 
        if (!found) { 
            System.out.println("No venues found of type " + type + "."); 
        } 
    } 
 
    private void countWeddingsPerVenue() { 
        if (venues.isEmpty()) { 
            System.out.println("No venues available."); 
            return; 
        } 
 
        System.out.println("Wedding count per venue:"); 
        for (Venue venue : venues) { 
            long count = weddings.stream().filter(wedding -> 
wedding.getVenue().equals(venue)).count(); 
            System.out.println(venue + ": " + count + " weddings"); 
        } 
    } 
}

